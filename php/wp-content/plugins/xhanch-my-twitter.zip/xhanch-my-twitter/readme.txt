=== Xhanch - My Twitter ===
Contributors: xhanch_studio
Plugin URI: http://xhanch.com/wp-plugin-my-twitter/
Author URI: http://xhanch.com
Donate link: http://xhanch.com/wp-plugin-my-twitter/
Tags: twitter, tweet, status, sidebar, post, posts, page, seo, xhanch, widget, plugin, code, avatar, content, social, plugins, css, text, admin, google, comments, links, image, cache
Requires at least: 2.3
Tested up to: 3.5
Stable tag: 2.7.5

The best plugin to display your latest tweets, replies, direct messages, retweets, auto and manual tweet and lots more. Support multiple accounts

== Description ==
Xhanch - My Twitter (developed by [Xhanch Studio](http://xhanch.com/ "Xhanch Studio")) is the best WordPress plugin to show/hide or include/exclude your latest tweets, replies from other members to you, replies from you to other members, retweets, and direct messages from your Twitter account(s).

You can customize it with our predefined flexible settings/options easily and it can be displayed via sidebar, post or page with advanced tweets filtering system.

You can also post a tweet/status directly from your website and auto tweet your newly published post/page.

An intensive cache system is provided as well that amke this plugin light weight.

Xhanch My Twitter is going to provide complete integration between your wordpress website and your twitter account. This plugin can connect to and access from multiple Twitter accounts.

We will keep improving this plugin in order to make this plugin to be the best Twitter plugin for WordPress


For complete features list, installation and setup, screen shots, FAQs, update logs/changelog, and support:

* [Plugin details](http://xhanch.com/wp-plugin-my-twitter/ "Xhanch - My Twitter")
* [Forum/community center](http://forum.xhanch.com/index.php/board,3.0.html "Forum/community center")
* [Change/update logs](http://forum.xhanch.com/index.php/board,13.0.html "Change/update logs")


[Click here to see All free plugins from Xhanch Studio](http://wordpress.org/extend/plugins/profile/xhanch_studio "Click here to see All free plugins from Xhanch Studio")

== Installation ==

[Click here for more detailed information about Xhanch - My Twitter and If you're having a problem with the plugin](http://xhanch.com/wp-plugin-my-twitter/ "Xhanch - My Twitter")

== Screenshots ==

[Click here for more detailed information about Xhanch - My Twitter and If you're having a problem with the plugin](http://xhanch.com/wp-plugin-my-twitter/ "Xhanch - My Twitter")

== Frequently Asked Questions ==

= What is Xhanch - My Twitter? =

[Click here for more detailed information about Xhanch - My Twitter and If you're having a problem with the plugin](http://xhanch.com/wp-plugin-my-twitter/ "Xhanch - My Twitter")

== Upgrade Notice ==

[Click here for complete change/update log the plugin](http://forum.xhanch.com/index.php/board,13.0.html "Xhanch - My Twitter")

== Support ==

[Click here to visit the forum for this plugin](http://forum.xhanch.com/index.php/board,3.0.html "Xhanch - My Twitter")

== Changelog ==

[Click here for complete change/update log the plugin](http://forum.xhanch.com/index.php/board,13.0.html "Xhanch - My Twitter")
