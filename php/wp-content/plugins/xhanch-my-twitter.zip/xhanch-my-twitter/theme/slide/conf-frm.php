<?php
	if(!defined('xmt'))
		exit;
?>
<table cellpadding="0" cellspacing="0">
	<tr>
		<td width="150px"><?php echo __('Slide Interval', 'xmt'); ?></td>
		<td width="200px"><input type="text" id="int_xmt_thm_sld_int" name="int_xmt_thm_sld_int" value="<?php echo $cfg['thm_sld_int']; ?>" size="5"  maxlength="5"/> ms</td>
		<td width="10px"></td>
		<td width="150px"></td>
		<td width="200px"></td>
	</tr>
</table>