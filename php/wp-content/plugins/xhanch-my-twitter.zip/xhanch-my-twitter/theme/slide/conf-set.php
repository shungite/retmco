<?php
	if(!defined('xmt'))
		exit;

	$tpl_cfg = array(
		'thm_sld_int' => intval(xmt_form_post('int_xmt_thm_sld_int')),
	);
?>